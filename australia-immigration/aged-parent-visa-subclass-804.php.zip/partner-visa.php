<?php include '../metadata.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <!-- Canonical tag -->
    <link rel="canonical" href="<?php echo $canonical_url; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($page_description); ?>"/>
    <meta name="keywords" content="<?php echo htmlspecialchars($page_keyword); ?>"/> <!-- Added keyword -->
    <meta property="og:title" content="<?php echo htmlspecialchars($page_title); ?>" />
    <meta property="og:description" content="<?php echo htmlspecialchars($page_description); ?>" />
    
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/images/favicons/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicons/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicons/favicon-16x16.png" />
    <link rel="manifest" href="/assets/images/favicons/site.webmanifest" />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">

    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="/assets/vendors/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/assets/vendors/animate/animate.min.css" />
    <link rel="stylesheet" href="/assets/vendors/animate/custom-animate.css" />
    <link rel="stylesheet" href="/assets/vendors/fontawesome/css/all.min.css" />
    <link rel="stylesheet" href="/assets/vendors/jarallax/jarallax.css" />
    <link rel="stylesheet" href="/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
    <link rel="stylesheet" href="/assets/vendors/nouislider/nouislider.min.css" />
    <link rel="stylesheet" href="/assets/vendors/nouislider/nouislider.pips.css" />
    <link rel="stylesheet" href="/assets/vendors/odometer/odometer.min.css" />
    <link rel="stylesheet" href="/assets/vendors/swiper/swiper.min.css" />
    <link rel="stylesheet" href="/assets/vendors/insur-icons/style.css">
    <link rel="stylesheet" href="/assets/vendors/insur-two-icon/style.css">
    <link rel="stylesheet" href="/assets/vendors/tiny-slider/tiny-slider.min.css" />
    <link rel="stylesheet" href="/assets/vendors/reey-font/stylesheet.css" />
    <link rel="stylesheet" href="/assets/vendors/owl-carousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/vendors/owl-carousel/owl.theme.default.min.css" />
    <link rel="stylesheet" href="/assets/vendors/bxslider/jquery.bxslider.css" />
    <link rel="stylesheet" href="/assets/vendors/bootstrap-select/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="/assets/vendors/vegas/vegas.min.css" />
    <link rel="stylesheet" href="/assets/vendors/jquery-ui/jquery-ui.css" />
    <link rel="stylesheet" href="/assets/vendors/timepicker/timePicker.css" />
    <link rel="stylesheet" href="/assets/vendors/ion.rangeSlider/css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="/assets/vendors/BuenosAires/stylesheet.css" />

    <!-- template styles -->
    <link rel="stylesheet" id="langLtr" href="/assets/css/insur.css" />
    <link rel="stylesheet" href="/assets/css/insur-responsive.css" />

	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
     
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-PR37ZR3');</script>
	<!-- End Google Tag Manager -->
 
	</head>

	<body>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PR37ZR3"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->

    <?php include '../header1.php';?>

    <div class="page-wrapper">

        <!--Page Header Start-->
		<section class="page-header" style="background: linear-gradient(to right, #01406b, #00bdce); color: #fff; padding: 70px 0 70px;">  
            <div class="container">
                <div class="page-header__inner">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="/" style="color: #ffffff;">Home</a></li>
                        <li style="color: #ffffff;"><span>/</span></li>
                        <li style="color: #ffffff;"><a href="https://www.immigrationxperts.com/australia-immigration/" style="color: #ffffff;">Australia</a></li>
                    </ul>
                    <h2 style="color: #b8e1f0;">Partner Visa</h2>
                </div>
            </div>
        </section>
				
        <!--Page Header End-->

        <!--News Details Start-->
        <section class="news-details">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7">
                        <div class="news-details__left">
                            <h1 class="section-title__title">Partner Visa</h1>
                            <p class="about-one__text-2">Live with your partner happily ever in Australia. The Spouse Visa as well as the Partner Visa is extended by the Department of Immigration and Border Protection to the specific categories (mentioned in this section) of potential immigrants. The <a href="/">Partner Visa</a> is available to those who are either married to or in a De Facto Relationship with any of the below</p>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> An Australian citizen</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> An Australian Permanent Resident</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> An eligible New Zealand citizen</p>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <p class="about-one__text-2">Here, it is very important to note that the applicant must be residing outside of Australia when applying for either Spouse Visa or the Partner Visa. In technical terms, Australia’s <a href="https://www.immigrationxperts.com/australia-immigration/spouse-visa/">Spouse Visa</a> or the Partner Visa is referred to as the Partner (Provisional) Visa (Subclass 309) and Partner (Migrant) Visa (Subclass 100). In more simple terms, the above cited Visas allow or enable the spouse or the de facto partner of an Australian citizen, a Permanent Australian Resident as well as an Eligible <a href="https://www.immigrationxperts.com/new-zealand-immigration/partners-and-children-visa/">New Zealand partner and children visa</a> or citizen to travel and live in Australia. That is, after meeting all the visa related procedures and conditions duly and to the one hundred percent satisfaction of the immigration authorities here in Australia.</p>
                            <p class="about-one__text-2"><span>Australia is a nation of OPPORTUNITIES.</span></p>
                            <p class="about-one__text-2">In more simple terms, the above cited Visas allow or enable the
                                spouse or the de facto partner of an Australian citizen, a <a href="https://www.immigrationxperts.com/permanent-residency-visa/">Permanent Australian Resident</a>
                                as well as an Eligible New Zealand citizen to travel to and live in Australia. That is,
                                after meeting all the visa related procedures and conditions duly and to the one hundred
                                per cent satisfaction of the immigration authorities here in Australia.</p>
                            <h3 class="txt mt-4">Process Of Partner Visa</h3>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> The application for the Partner (Provisional) Visa (Subclass 309) is the
                                            first stage</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Once you have received the Provisional or the Temporary Visa, you become
                                            eligible to apply for the Partner (Migrant) Visa (Subclass 100) and try for
                                            a long-term Australian residence and live with your partner in Australia</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> You submit only one visa application for the Provisional or the Migrant
                                            visas and thereby also get to pay only once</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Your application is processed in two stages, and that too, with a time
                                            period of two years in between the stages</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> You must be residing outside of Australia, when applying for both the
                                            Partner (Provisional) Visa (Subclass 309) and Partner (Migrant) Visa
                                            (Subclass 100)</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Though, you are allowed to be either outside or inside Australia when
                                            applying for the Partner (Migrant) Visa (Subclass 100)</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> You can obtain additional information from the Partner Migration booklet
                                            which is very much available online</p>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <h3 class="txt mt-4">Conditions For subclass 864:</h3>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Though, you are allowed to be either outside or inside Australia when
                                            applying for the Partner (Migrant) Visa (Subclass 100)</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Most important is to meet the balance of family test</p>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <h3 class="txt mt-4">The Balance of Family Test requirements:</h3>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Half of your children must live permanently in Australia.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> More of your children live permanently in Australia than in any other
                                            country.</p>
                                    </div>
                                </div>
                            </div>
                            <br>
                        </div>
						<?php include '../assistyou.php';?>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <?php include 'australia-sidebar.php';?>
                    </div>
                </div>

            </div>

        </section>
        <!--News Details End-->

        <?php include 'partner.php';?>
        <?php include '../footer.php';?>

    </div><!-- /.page-wrapper -->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fas fa-plane"></i></a>

    <script src="/assets/vendors/jquery/jquery-3.6.0.min.js"></script>
    <script src="/assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/vendors/jarallax/jarallax.min.js"></script>
    <script src="/assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
    <script src="/assets/vendors/jquery-appear/jquery.appear.min.js"></script>
    <script src="/assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
    <script src="/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="/assets/vendors/jquery-validate/jquery.validate.min.js"></script>
    <script src="/assets/vendors/nouislider/nouislider.min.js"></script>
    <script src="/assets/vendors/odometer/odometer.min.js"></script>
    <script src="/assets/vendors/swiper/swiper.min.js"></script>
    <script src="/assets/vendors/tiny-slider/tiny-slider.min.js"></script>
    <script src="/assets/vendors/wnumb/wNumb.min.js"></script>
    <script src="/assets/vendors/wow/wow.js"></script>
    <script src="/assets/vendors/isotope/isotope.js"></script>
    <script src="/assets/vendors/countdown/countdown.min.js"></script>
    <script src="/assets/vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="/assets/vendors/bxslider/jquery.bxslider.min.js"></script>
    <script src="/assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
    <script src="/assets/vendors/vegas/vegas.min.js"></script>
    <script src="/assets/vendors/jquery-ui/jquery-ui.js"></script>
    <script src="/assets/vendors/timepicker/timePicker.js"></script>
    <script src="/assets/vendors/circleType/jquery.circleType.js"></script>
    <script src="/assets/vendors/circleType/jquery.lettering.min.js"></script>
    <script src="/assets/vendors/ion.rangeSlider/js/ion.rangeSlider.min.js"></script>



    <!-- template js -->
     <script src="/assets/js/insur.js"></script>
	 <script src="/assets/js/country.js"></script>
</body>

</html>