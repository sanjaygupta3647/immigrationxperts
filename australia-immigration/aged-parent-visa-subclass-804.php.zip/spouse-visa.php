<?php include '../metadata.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <!-- Canonical tag -->
    <link rel="canonical" href="<?php echo $canonical_url; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($page_description); ?>"/>
    <meta name="keywords" content="<?php echo htmlspecialchars($page_keyword); ?>"/> <!-- Added keyword -->
    <meta property="og:title" content="<?php echo htmlspecialchars($page_title); ?>" />
    <meta property="og:description" content="<?php echo htmlspecialchars($page_description); ?>" />
    
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/images/favicons/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicons/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicons/favicon-16x16.png" />
    <link rel="manifest" href="/assets/images/favicons/site.webmanifest" />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">

    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="/assets/vendors/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/assets/vendors/animate/animate.min.css" />
    <link rel="stylesheet" href="/assets/vendors/animate/custom-animate.css" />
    <link rel="stylesheet" href="/assets/vendors/fontawesome/css/all.min.css" />
    <link rel="stylesheet" href="/assets/vendors/jarallax/jarallax.css" />
    <link rel="stylesheet" href="/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
    <link rel="stylesheet" href="/assets/vendors/nouislider/nouislider.min.css" />
    <link rel="stylesheet" href="/assets/vendors/nouislider/nouislider.pips.css" />
    <link rel="stylesheet" href="/assets/vendors/odometer/odometer.min.css" />
    <link rel="stylesheet" href="/assets/vendors/swiper/swiper.min.css" />
    <link rel="stylesheet" href="/assets/vendors/insur-icons/style.css">
    <link rel="stylesheet" href="/assets/vendors/insur-two-icon/style.css">
    <link rel="stylesheet" href="/assets/vendors/tiny-slider/tiny-slider.min.css" />
    <link rel="stylesheet" href="/assets/vendors/reey-font/stylesheet.css" />
    <link rel="stylesheet" href="/assets/vendors/owl-carousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/vendors/owl-carousel/owl.theme.default.min.css" />
    <link rel="stylesheet" href="/assets/vendors/bxslider/jquery.bxslider.css" />
    <link rel="stylesheet" href="/assets/vendors/bootstrap-select/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="/assets/vendors/vegas/vegas.min.css" />
    <link rel="stylesheet" href="/assets/vendors/jquery-ui/jquery-ui.css" />
    <link rel="stylesheet" href="/assets/vendors/timepicker/timePicker.css" />
    <link rel="stylesheet" href="/assets/vendors/ion.rangeSlider/css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="/assets/vendors/BuenosAires/stylesheet.css" />

    <!-- template styles -->
    <link rel="stylesheet" id="langLtr" href="/assets/css/insur.css" />
    <link rel="stylesheet" href="/assets/css/insur-responsive.css" />

	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
     
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-PR37ZR3');</script>
	<!-- End Google Tag Manager -->
 
	</head>

	<body>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PR37ZR3"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->

      <?php include '../header1.php';?>

    <div class="page-wrapper">

        <!--Page Header Start-->
		<section class="page-header" style="background: linear-gradient(to right, #01406b, #00bdce); color: #fff; padding: 70px 0 70px;">  
            <div class="container">
                <div class="page-header__inner">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="/" style="color: #ffffff;">Home</a></li>
                        <li style="color: #ffffff;"><span>/</span></li>
                        <li style="color: #ffffff;"><a href="https://www.immigrationxperts.com/australia-immigration/" style="color: #ffffff;">Australia</a></li>
                    </ul>
                    <h2 style="color: #b8e1f0;">Spouse Visa</h2>
                </div>
            </div>
        </section>
		        
        <!--Page Header End-->

        <!--News Details Start-->
        <section class="news-details">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7">
                        <div class="news-details__left">
                            <h1 class="section-title__title">Spouse Visa</h1>
                            <p class="about-one__text-2">Suppose you have just gotten married to your long term loving boyfriend or girlfriend and then you get the news that your spouse has got the visa for Australia and he or she is ready to chase down that dream job of theirs. Living in different countries all across the world while your spouse or partner is migrating to Australia can be harrowing for anyone considering the distance.
However, there is a provision here for the partner who is left behind called Spouse Visa.The <a href="/">Spouse Visa</a> for Australia can only be garnered by those who fall under any of the following categories:
                            </p>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Spouse is an Australian Citizen.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Surviving spouse of an Australian Citizen</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> After becoming eligible for Spouse Visa for Australia through above requirements, it is time to see whether the applicant fulfills other eligibility criteria to become a citizen of Australia.</p>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <p class="about-one__text-2"><span>Australia is a nation of OPPORTUNITIES.</span></p>
                            <h3 class="txt mt-4">Spouse Visa for Australia Eligibility Criteria</h3>
                            <p class="about-one__text-2">The spouse or partner of the applicant should be an Australian Citizen or the applicant should be the surviving partner or spouse of the Australian citizen. After meeting this criteria there furthermore eligibility requirements that you as an applicant need to fulfill:</p>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Need to be considered a permanent resident while deciding or applying for
                                            the visa.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Some general requirement of residence should be met.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Good character is imperative.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Applicants below the age of 60 years should have basic and general English
                                            knowledge.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Those under the age of 60 are knowledgeable and have complete information of
                                            the privileges and responsibilities incurred with Australian citizenship.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> The intention behind the application is to either stay in Australia or has
                                            close contact with the country.</p>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <h3 class="txt mt-4">General Residence Criteria:</h3>
                            <p class="about-one__text-2">The basis for General Residence is on the quantity of time that
                                the applicant has spent in Australia. For this the criteria is as follows:</p>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Applicant should have a valid Australian visa on which he or she should have
                                            spent four years at least in the country ending immediately before
                                            applying for the Spouse visa for Australia.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Have a permanent residency for at least 12 months before applying for the visa.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="contened-icon-box">
                                <div class="contened-icon">
                                    <div class="cont-icon"><i class="fa-regular fa-circle-check"></i></div>
                                </div>
                                <div class="contened-content">
                                    <div class="contened-desc">
                                        <p> Have been out of Australia for no more than 1 year from the four years and not more than 90 days in the 1 year of permanent residency.</p>
                                    </div>
                                </div>
                            </div>
                            <br>
                            
                            <h3 class="txt mt-4">How to Know Your Permanent Residency?</h3>
                            <p class="about-one__text-2">Suppose the applicant got a permanent resident visa before visiting Australia then the date on which he or she arrived in the country will be counted as the permanent resident date.
                                On the other hand, if the <a href="https://www.immigrationxperts.com/permanent-residency-visa/">permanent residency visa</a> was granted after coming into the country, then the date on which permanent resident visa was issued will be counted as the permanent resident date.
                                </br>To know whether the applicant meets the requirement of general residency a called Residence Requirement Calculator can be used to calculate.</p>
                            
                            <h3 class="txt mt-4">What Are The Requirements For Permanent Residency?</h3>
                            <p class="about-one__text-2">The requirements for Permanent Residency (PR) vary by country, but generally include factors such as age, education, work experience, language proficiency, and adaptability. Applicants often need to demonstrate a certain level of education and skilled work experience relevant to the country's labor market. Proficiency in the official language(s) of the country is typically required, and applicants may need to pass a language test. Health and character assessments, such as background checks and medical exams, are also common. Some countries use a points-based system to evaluate eligibility, where applicants must score a minimum number of points to qualify for PR.
                               </br>  </br>  In case the requirements for general residence are not met by the applicant, the time they spent outside Australia after receiving the permanent resident visa for the four years ending immediately before applying for spouse visa or <a href="https://www.immigrationxperts.com/australia-immigration/partner-visa/">partner visa </a> could be considered as the time spent in the country. This is known as ministerial discretion that can be applied by the applicant in the case wherein they provide proper evidence for their legal relationship with their spouse or partner who is an Australian citizen and have also kept in close contact with Australia during their absence.</p>
                            
                            <h3 class="txt mt-4">Children</h3>
                            <p class="about-one__text-2">The children below the age of 16 years can get <a href="https://www.immigrationxperts.com/australia-immigration/benefits-of-immigration-to-australia/">benefits of immigration to 
                            Australia</a> that can be included in the application for Australian citizenship. However, 
                            the general residence requirement for children below 16 years of age is not needed.</p>
                        </div>
						<?php include '../assistyou.php';?>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <?php include 'australia-sidebar.php';?>
                    </div>
                </div>

            </div>

        </section>
        <!--News Details End-->

        <?php include 'partner.php';?>
        <?php include '../footer.php';?>

    </div><!-- /.page-wrapper -->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fas fa-plane"></i></a>

    <script src="/assets/vendors/jquery/jquery-3.6.0.min.js"></script>
    <script src="/assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/vendors/jarallax/jarallax.min.js"></script>
    <script src="/assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
    <script src="/assets/vendors/jquery-appear/jquery.appear.min.js"></script>
    <script src="/assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
    <script src="/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="/assets/vendors/jquery-validate/jquery.validate.min.js"></script>
    <script src="/assets/vendors/nouislider/nouislider.min.js"></script>
    <script src="/assets/vendors/odometer/odometer.min.js"></script>
    <script src="/assets/vendors/swiper/swiper.min.js"></script>
    <script src="/assets/vendors/tiny-slider/tiny-slider.min.js"></script>
    <script src="/assets/vendors/wnumb/wNumb.min.js"></script>
    <script src="/assets/vendors/wow/wow.js"></script>
    <script src="/assets/vendors/isotope/isotope.js"></script>
    <script src="/assets/vendors/countdown/countdown.min.js"></script>
    <script src="/assets/vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="/assets/vendors/bxslider/jquery.bxslider.min.js"></script>
    <script src="/assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
    <script src="/assets/vendors/vegas/vegas.min.js"></script>
    <script src="/assets/vendors/jquery-ui/jquery-ui.js"></script>
    <script src="/assets/vendors/timepicker/timePicker.js"></script>
    <script src="/assets/vendors/circleType/jquery.circleType.js"></script>
    <script src="/assets/vendors/circleType/jquery.lettering.min.js"></script>
    <script src="/assets/vendors/ion.rangeSlider/js/ion.rangeSlider.min.js"></script>



    <!-- template js -->
     <script src="/assets/js/insur.js"></script>
	 <script src="/assets/js/country.js"></script>
</body>

</html>