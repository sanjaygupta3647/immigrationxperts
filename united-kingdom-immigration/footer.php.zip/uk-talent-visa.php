<?php include '../metadata.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <!-- Canonical tag -->
    <link rel="canonical" href="<?php echo $canonical_url; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($page_description); ?>"/>
    <meta name="keywords" content="<?php echo htmlspecialchars($page_keyword); ?>"/> <!-- Added keyword -->
    <meta property="og:title" content="<?php echo htmlspecialchars($page_title); ?>" />
    <meta property="og:description" content="<?php echo htmlspecialchars($page_description); ?>" />
    
    
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/images/favicons/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicons/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicons/favicon-16x16.png" />
    <link rel="manifest" href="/assets/images/favicons/site.webmanifest" />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">

    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="/assets/vendors/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/assets/vendors/animate/animate.min.css" />
    <link rel="stylesheet" href="/assets/vendors/animate/custom-animate.css" />
    <link rel="stylesheet" href="/assets/vendors/fontawesome/css/all.min.css" />
    <link rel="stylesheet" href="/assets/vendors/jarallax/jarallax.css" />
    <link rel="stylesheet" href="/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
    <link rel="stylesheet" href="/assets/vendors/nouislider/nouislider.min.css" />
    <link rel="stylesheet" href="/assets/vendors/nouislider/nouislider.pips.css" />
    <link rel="stylesheet" href="/assets/vendors/odometer/odometer.min.css" />
    <link rel="stylesheet" href="/assets/vendors/swiper/swiper.min.css" />
    <link rel="stylesheet" href="/assets/vendors/insur-icons/style.css">
    <link rel="stylesheet" href="/assets/vendors/insur-two-icon/style.css">
    <link rel="stylesheet" href="/assets/vendors/tiny-slider/tiny-slider.min.css" />
    <link rel="stylesheet" href="/assets/vendors/reey-font/stylesheet.css" />
    <link rel="stylesheet" href="/assets/vendors/owl-carousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="/assets/vendors/owl-carousel/owl.theme.default.min.css" />
    <link rel="stylesheet" href="/assets/vendors/bxslider/jquery.bxslider.css" />
    <link rel="stylesheet" href="/assets/vendors/bootstrap-select/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="/assets/vendors/vegas/vegas.min.css" />
    <link rel="stylesheet" href="/assets/vendors/jquery-ui/jquery-ui.css" />
    <link rel="stylesheet" href="/assets/vendors/timepicker/timePicker.css" />
    <link rel="stylesheet" href="/assets/vendors/ion.rangeSlider/css/ion.rangeSlider.min.css">
    <link rel="stylesheet" href="/assets/vendors/BuenosAires/stylesheet.css" />

    <!-- template styles -->
    <link rel="stylesheet" id="langLtr" href="/assets/css/insur.css" />
    <link rel="stylesheet" href="/assets/css/insur-responsive.css" />

 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
     
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-PR37ZR3');</script>
	<!-- End Google Tag Manager -->
 
	</head>

	<body>
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PR37ZR3"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->

      <?php include '../header1.php';?>

    <div class="page-wrapper">

        <!--Page Header Start-->
        <section class="page-header" style="background: linear-gradient(to right, #01406b, #00bdce); color: #fff; padding: 70px 0 70px;">  
            <div class="container">
                <div class="page-header__inner">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="/" style="color: #ffffff;">Home</a></li>
                        <li style="color: #ffffff;"><span>/</span></li>
                        <li style="color: #ffffff;"><a href="https://www.immigrationxperts.com/united-kingdom-immigration/" style="color: #ffffff;">United Kingdom</a></li>
                    </ul>
                    <h2 style="color: #b8e1f0;">United Kingdom Talent Visa</h2>
                </div>
            </div>
        </section>
       
        <!--Page Header End-->

        <!--News Details Start-->
        <section class="news-details">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7">
                        <div class="news-details__left">
                            <h1 class="section-title__title">United Kingdom Talent Visa</h1>
                            <p class="about-one__text-2">This particular category of visa allows only a limited number
                                of individuals to enter in the United Kingdom (UK). This particularly includes
                                individuals who are either being recognized as leaders or emerging leaders in limited
                                number of qualified fields.</p>
                            <p class="about-one__text-2">It is required for your to be eligible under one of the visa
                                schemes, that is either Tier 1 Exceptional Talent Visa or Tier 1 Exceptional Promise
                                Visa streams. </p>
                            <p class="about-one__text-2">One of the most important benefit of this particular
                                Exceptional Talent visa (Tier 1) when compared to that of Tier 2 Visa and Tier 2 Sponsor
                                Licence visa streams is that: “You receive the right to work freely for any employer or
                                can start your own business or even work as self-employed”. </p>
                            <p class="about-one__text-2">However, before applying for this visa, the applicants should
                                receive endorsement from a one of the recognized designated competent body and applying
                                for same through UK Home Office application under following fields:</p>
                            <p class="about-one__text-2">Sciences, Engineering, Medicine, Humanities, Digital
                                Technology, Architecture, Fashion, Films and Television and Arts</p>
                            <p class="about-one__text-2">The Exceptional Talent visa (Tier 1) visa has an annual limit
                                of only 2000 places that are available under this visa category, which is being decided
                                by the UK Home Office.</p>
                            <h3 class="txt mt-4">Eligibility for the application process for Exceptional Talent visa
                                (Tier 1)</h3>
                            <p class="about-one__text-2"><span>Stage 1: Apply to the Home Office for Endorsement </span>
                            </p>
                            <p class="about-one__text-2">In order to receive Exceptional Talent visa (Tier 1), you are
                                required to apply to get endorsed either as a leader (exceptional leader) or an emerging
                                leader (exceptional promise).</p>
                            <p class="about-one__text-2">Your application will then be reviewed by the particular
                                organization that is related to your particular qualifying field or occupation, and is
                                called as “designated competent body”. These are:</p>
                            <ul class="list-unstyled about-two__points">
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>The Royal Society, for the field of Science and Medicine</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>The Royal Academy of Engineering, for the field of engineering</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>The British Academy, for the field of humanities</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>Tech Nation, for the field of digital technology</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>Arts Council England, for the field of arts and culture</p>
                                    </div>
                                </li>
                            </ul>
                            <p class="about-one__text-2"><span>Stage 2: Visa application </span></p>
                            <p class="about-one__text-2">If you get through the Stage 1, you will receive an email the
                                Home Office. It will also be having copy of your endorsement letter attached along with
                                it, that will be required for the visa application. </p>
                            <ul class="list-unstyled about-two__points">
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>an existing passport or any other valid travel document for identification
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>a separate passport photograph (if asked)</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>a print of your endorsement letter, if you have already received it</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>results of your tuberculosis test if you belong from the country where the
                                            tests are being taken</p>
                                    </div>
                                </li>
                            </ul>
                            <p class="about-one__text-2">You are also required to provide a certified translation of all
                                the documents that are not written in English or Welsh. You may be asked to provide
                                certain additional documents depending on your individual circumstances.</p>
                            <h3 class="txt mt-4">How long can you stay in UK </h3>
                            <p class="about-one__text-2">The total duration of your stay in UK on Exceptional Talent
                                visa (Tier 1) would depend on whether you are already staying in UK. If you are applying
                                from outside UK, then you can stay for a period of 5 years and 4 months. However, those
                                who would be switching on this visa while living in UK, then you can stay for a maximum
                                period of 5 years.</p>
                            <p class="about-one__text-2">If you are granted an Exceptional Talent visa (Tier 1), then
                                you can apply for resident visa on the basis of your stay in UK for a period of three
                                years. The application can be submitted 28-days earlier before completion of three years
                                stay in UK. However, if you would be holding Exceptional Talent Promise visa (Tier 1)
                                Promise Visa, then you have to wait for up to five years (excluding 28-days) before you
                                can apply further for an indefinite leave to remain in UK.</p>
                            <h3 class="txt mt-4">What you can and cannot do</h3>
                            <p class="about-one__text-2"><span>You can:</span></p>
                            <ul class="list-unstyled about-two__points">
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>work under an employer, start your own business or work as a self-employed
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>change your job without informing the Home Office</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>engage in a voluntary work</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>travel to other countries and then return back to UK</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>bring your family members along with you</p>
                                    </div>
                                </li>
                            </ul>
                            <p class="about-one__text-2"><span>You cannot:</span></p>
                            <ul class="list-unstyled about-two__points">
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>get public funds</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>work as a doctor or a dentist who is in training </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-check"></i>
                                    </div>
                                    <div class="text">
                                        <p>work as a professional sports coach or sportsperson</p>
                                    </div>
                                </li>

                            </ul>

                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                    <?php include 'uk-sidebar.php';?>
                    </div>
                </div>


            </div>

        </section>
        <!--News Details End-->

        <?php include 'partner.php';?>
        <?php include '../footer.php';?>

    </div><!-- /.page-wrapper -->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fas fa-plane"></i></a>

    <script src="/assets/vendors/jquery/jquery-3.6.0.min.js"></script>
    <script src="/assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/vendors/jarallax/jarallax.min.js"></script>
    <script src="/assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
    <script src="/assets/vendors/jquery-appear/jquery.appear.min.js"></script>
    <script src="/assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
    <script src="/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="/assets/vendors/jquery-validate/jquery.validate.min.js"></script>
    <script src="/assets/vendors/nouislider/nouislider.min.js"></script>
    <script src="/assets/vendors/odometer/odometer.min.js"></script>
    <script src="/assets/vendors/swiper/swiper.min.js"></script>
    <script src="/assets/vendors/tiny-slider/tiny-slider.min.js"></script>
    <script src="/assets/vendors/wnumb/wNumb.min.js"></script>
    <script src="/assets/vendors/wow/wow.js"></script>
    <script src="/assets/vendors/isotope/isotope.js"></script>
    <script src="/assets/vendors/countdown/countdown.min.js"></script>
    <script src="/assets/vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="/assets/vendors/bxslider/jquery.bxslider.min.js"></script>
    <script src="/assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
    <script src="/assets/vendors/vegas/vegas.min.js"></script>
    <script src="/assets/vendors/jquery-ui/jquery-ui.js"></script>
    <script src="/assets/vendors/timepicker/timePicker.js"></script>
    <script src="/assets/vendors/circleType/jquery.circleType.js"></script>
    <script src="/assets/vendors/circleType/jquery.lettering.min.js"></script>
    <script src="/assets/vendors/ion.rangeSlider/js/ion.rangeSlider.min.js"></script>



    <!-- template js -->
     <script src="/assets/js/insur.js"></script>
	 <script src="/assets/js/country.js"></script>
</body>

</html>