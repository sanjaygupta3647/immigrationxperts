<div class="modal fade" id="Modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="max-width: 40%; height: auto" role="document">
            <div class="modal-content" style="border: 15px solid white;border-radius: 0px;background-image: url(assets/images/visa2.webp);">
                <div class="modal-header1 border-0">
                    <button type="button" class="btn btnclose ms-auto" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times text-white"></i></button>
                </div>
                <div class="modal-body">
                    <h4 class="text-dark text-center">FREE VISA ASSESSMENT FORM</h4>   
 					  <form   action="newmail/form1mail" method="POST">
                           
                    
					  <div class="form-group">
							<input type="text" name="your-name" class="form-control" placeholder="Name*" required autocomplete="off">                        
							  <p class="help-block text-danger"></p>
						</div>
					
						<div class="form-group">
							<input type="email" name="your-email" class="form-control email" placeholder="Email*" required autocomplete="off">
							<p class="help-block text-danger"></p>
						</div>

						<div class="form-group">							
							<input type="tel" class="form-control boderall" name="your-phone" required id="checkPhone" placeholder="Phone*" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '');">

							<p class="help-block text-danger"></p>
						</div>
					 
                    <div class="form-group">
                       <input type="text" name="your-city" class="form-control city" placeholder="City*" required>
						  </span>
                    </div>
                      <div class="form-group">
						<select class="form-control" placeholder="Select Occuption *" id="qul" name="ConsultingBranch3" required="required" data-validation-required-message="Occupation is required." aria-invalid="false">	<option value="">Select Nearest Branch*</option>
							<option value="Noida Head Office">Noida Head Office</option>
							<option value="Delhi">Delhi</option>
							<option value="Lucknow">Lucknow</option>
							<option value="Mumbai">Mumbai</option>
							<option value="Pune">Pune</option>
							<option value="Hyderabad-Kukatpally">Hyderabad-Kukatpally</option>
							<option value="Hyderabad-Ameerpet">Hyderabad-Ameerpet</option>
							<option value="Chennai">Chennai</option>
							<option value="Other">Other</option>
						</select>
					</span>
						  </div>
						</div>
						<div class="text form-group pl-4" style="margin-left: 20px;">
							<label for="terms">
								<input type="checkbox" name="terms" id="terms" required  class="text-light">
								I agree to the <a href="https://apicalvisaexperts.com/terms-conditions.php" target="_blank">terms and conditions</a>
							</label>
						</div>
											
						<div class="col-lg-12">
							<div id="html_element1"></div>
						</div>
						<div class="text-center button mb-3">
							<input type="submit" name="BannForm" id="BannForm" class="btn btn-primary tra-black-hover submit" value="Get free consultation">
						</div>						
					</form>	   
                        
                    </div>
                </div>
            </div>
        </div>
    </div>